
from PIL import Image
import subprocess

import win32clipboard
import win32con
import webbrowser
import pyautogui
import random
import string
import pyperclip
import os
import time
from io import BytesIO
image_number = 1
Pic_number = 0
image_path = f'E:\I Love Camping\All Camping Images'
can_create_image = True
image_not_found = True
Image_prompt = 'Create a square image with a 1:1 aspect ratio and a resolution of 1024x1024 pixels, optimized for Facebook posts. The image should closely replicate the original in terms of design, style, and overall visual feel, while keeping the text exactly as it is without any modifications'
word_length = 7
already_have_tap = False
already_did_image = False
wait_time = 30
def reopen_AI():
    webbrowser.open('gemini.google.com/app')

def open_AI():
    global already_have_tap
    if not already_have_tap:
        webbrowser.open('gemini.google.com/app')
        already_have_tap = True
    open_chat()

def open_chat():
    global already_did_image
    if already_did_image == False:
        time.sleep(7)

        screenWidth, screenHeight = pyautogui.size()
        centerX = screenWidth / 2
        centerY = screenHeight / 2
        pyautogui.moveTo(centerX, centerY)
        pyautogui.move(0, 350, duration=0.5)
        pyautogui.click()
        paste()
    elif already_did_image == True:
        pyautogui.move(0, 300, duration=0.5)
        pyautogui.click()
        
        paste()
    
    pass



def paste():
    time.sleep(4)
    pyautogui.hotkey('ctrl', 'v')
    pyperclip.copy(Image_prompt)
    time.sleep(4)
    pyautogui.hotkey('ctrl', 'v')
    time.sleep(8)
    pyautogui.press('enter')
    pyautogui.moveRel(0, -100, duration=0.5)
    save_image()
    pass

def save_image():
    global image_number, Pic_number,image_path, can_create_image,wait_time, image_not_found, already_did_image, Pic_number
    time.sleep(wait_time)
    scroll()
    screenWidth, screenHeight = pyautogui.size()
    centerX = screenWidth / 2
    centerY = screenHeight / 2
    pyautogui.moveTo(centerX, centerY)
    pyautogui.rightClick()
    time.sleep(1)
    current_x, current_y = pyautogui.position()
    pyautogui.move(50, 0, duration=0.2)
    pyautogui.move(0, 50, duration=0.2)
    pyautogui.click()
    time.sleep(1)
    name:str = 'camping image'
    random_word = ''.join(random.choice(string.ascii_lowercase) for _ in range(word_length))
    random_word = name + ' ' + random_word
    pyperclip.copy(random_word)
    pyautogui.hotkey('ctrl', 'v')
    time.sleep(1)
    pyautogui.hotkey('enter')
    if Pic_number == 3:
        Pic_number = 0
        command = ["taskkill", "/f", "/im", "msedge.exe"]
        
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        already_did_image = True
        can_create_image = True
        image_not_found = True
        time.sleep(4)
        webbrowser.open('gemini.google.com/app')
        wait_time = 30
        time.sleep(3)
        pass
    if Pic_number != 3:
        already_did_image = True
        can_create_image = True
        image_not_found = True
        Pic_number += 1
     
        
    wait_time += 8
    print(f"number: {Pic_number}")
    print(f"wait time: {wait_time}")
    print
    time.sleep(5)
    find_image()

def copyImage(path):
    print('Copying Image....')
    image = Image.open(path)
    output = BytesIO()
    image.save(output, 'BMP')
    data = output.getvalue()[14:]
    output.close()
    win32clipboard.OpenClipboard()
    win32clipboard.EmptyClipboard()
    win32clipboard.SetClipboardData(win32con.CF_DIB, data)
    win32clipboard.CloseClipboard()
    os.remove(path)
    print('Image Copied.....')
    open_AI()

def Browser(url):
    webbrowser.open(url)

def scroll():
    for _ in range(3):
        pyautogui.scroll(-500)
        time.sleep(1)
def find_image():
    global image_path, can_create_image, image_not_found, already_have_tap
    
    folder_path = f'E:\I Love Camping\All Camping Images'
    valid_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp']
    
    while True:
        if image_not_found:
            found_image = False
            for filename in os.listdir(folder_path):
                file_extension = os.path.splitext(filename)[1].lower()
                if file_extension in valid_extensions:
                    image_path = os.path.join(folder_path, filename)
                    print(f'Image Found: {image_path}')
                    copyImage(image_path)
                    found_image = True
                    image_not_found = False
                    can_create_image = False
                    already_did_image = False
                    break 
            
            if not found_image:
                print('No images found in the folder. Waiting...')
            

while True:
    
    if can_create_image:
        find_image()
